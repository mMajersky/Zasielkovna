<script setup>

</script>

<template>
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <p>Copyright © 2022 Mexant Co., Ltd. All Rights Reserved. 
            
            <br>Designed by <a title="CSS Templates" rel="sponsored" href="https://templatemo.com" target="_blank">TemplateMo</a></p>
          </div>
        </div>
      </div>
    </footer>
</template>

<style>

</style>