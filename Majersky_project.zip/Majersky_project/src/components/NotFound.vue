
<template>
<div class="section-heading">
    <h6>We looked everywhere!</h6>
    <h4>Maybe try again?</h4>
</div>
</template>
