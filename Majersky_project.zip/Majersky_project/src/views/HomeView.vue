<script setup>
import banner from '../components/Banner.vue'
</script>

<template>
  <div>
    <div class="swiper-container" id="top">
      <div class="swiper-wrapper">
        
          <div class="slide-inner" style="background-image:url(assets/images/slide-01.jpg)">
            <div class="container">
              <div class="row">
                <div class="col-lg-8">
                  <div class="header-text">
                    <h2>Experience<em> fastest</em> delivery you could <em>imagine</em></h2>
                    <div class="div-dec"></div>
                    <p>From swift personal deliveries to comprehensive long-term solutions for businesses, our reliable and efficient services are designed to meet your unique needs. Explore our range of storage units, ensuring the utmost security for your belongings. Trust us to deliver beyond expectations, making every experience a satisfaction.</p>
                    <div class="buttons">
                      <div class="green-button">
                        <a href="#">Discover More</a>
                      </div>
                      <div class="orange-button">
                        <a href="#">Contact Us</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        
        
        
      </div>

    </div>
  
    <!-- ***** Main Banner Area End ***** -->
  
    <section class="services" id="services">
      <div class="container">
        <div class="row">
          <div >
            <div class="service-item">
              <i class="fas fa-archive"></i>
              <h4>Reliability</h4>
              <p>Experience timely deliveries with our courier services, ensuring unmatched reliability for your valuable shipments.</p>
            </div>
          </div>
          <div >
            <div class="service-item">
              <i class="fas fa-cloud"></i>
              <h4>Safety</h4>
              <p>Our courier services guarantee secure and protected transportation throughout the entire delivery process.</p>
            </div>
          </div>
          
          
          <div >
            <div class="service-item">
              <i class="fas fa-archway"></i>
              <h4>Storage</h4>
              <p>Solution for your temporary storage needs with our range of available storage units, providing secure spaces.</p>
            </div>
          </div>
          <div >
            <div class="service-item">
              <i class="fas fa-puzzle-piece"></i>
              <h4>Fast Customer Support</h4>
              <p>Do not be hesitated to contact us if you have any question or concern about our services.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  
  <banner></banner>
  

  
    
  
    
  </div>
  </template>
