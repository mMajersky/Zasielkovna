<script setup>

</script>

<template>
  <div>
      <div class="page-heading">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="header-text">
          <h2>Contact Us</h2>
          <div class="div-dec"></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ***** Main Banner Area End ***** -->

<section class="map">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div id="map">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2791.78997548554!2d144.9805125252687!3d-37.84132841005892!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad6681f3e9cb7e1%3A0x9d52778f56cab5a8!2sFawkner%20Park!5e1!3m2!1sen!2sth!4v1648201596364!5m2!1sen!2sth" width="100%" height="450px" frameborder="0" style="border:0; border-radius: 5px; position: relative; z-index: 2;" allowfullscreen=true></iframe>
        </div>
      </div>
      <div class="col-lg-10 offset-lg-1">
        <div class="row">
          <div class="col-lg-4">
            <div class="info-item">
              <i class="fa fa-envelope"></i>
              <h4>Email Address</h4>
              <a href="#">info@company.com</a>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="info-item">
              <i class="fa fa-phone"></i>
              <h4>Phone Number</h4>
              <a href="#">010-020-0340</a>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="info-item">
              <i class="fa fa-map-marked-alt"></i>
              <h4>Address</h4>
              <a href="#">Victoria, Australia</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="contact-us-form">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 offset-lg-3">
        <div class="section-heading">
          <h6>Contact Us</h6>
          <h4>Feel free to message us</h4>
        </div>
      </div>
      <div class="col-lg-10 offset-lg-1">
        <form id="contact" action="" method="post">
          <div class="row">
            <div class="col-lg-6">
              <fieldset>
                <input type="name" name="name" id="name" placeholder="Your Name..." autocomplete="on" required>
              </fieldset>
            </div>
            <div class="col-lg-6">
              <fieldset>
                <input type="phone" name="phone" id="phone" placeholder="Your Phone..." autocomplete="on" required>
              </fieldset>
            </div>
            <div class="col-lg-6">
              <fieldset>
                <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your E-mail..." required=true>
              </fieldset>
            </div>
            <div class="col-lg-6">
              <fieldset>
                <input type="subject" name="subject" id="subject" placeholder="Subject..." autocomplete="on" >
              </fieldset>
            </div>
            <div class="col-lg-12">
              <fieldset>
                <textarea name="message" id="message" placeholder="Your Message"></textarea>
              </fieldset>
            </div>
            <div class="col-lg-12">
              <fieldset>
                <button type="submit" id="form-submit" class="orange-button">Send Message</button>
              </fieldset>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>

<section class="partners">
  <div class="container">
    <div class="row">
      <div class="col-lg-2 col-sm-4 col-6">
        <div class="item">
          <img src="./assets/images/client-01.png" alt="">
        </div>
      </div>
      <div class="col-lg-2 col-sm-4 col-6">
        <div class="item">
          <img src="./assets/images/client-01.png" alt="">
        </div>
      </div>
      <div class="col-lg-2 col-sm-4 col-6">
        <div class="item">
          <img src="./assets/images/client-01.png" alt="">
        </div>
      </div>
      <div class="col-lg-2 col-sm-4 col-6">
        <div class="item">
          <img src="./assets/images/client-01.png" alt="">
        </div>
      </div>
      <div class="col-lg-2 col-sm-4 col-6">
        <div class="item">
          <img src="./assets/images/client-01.png" alt="">
        </div>
      </div>
      <div class="col-lg-2 col-sm-4 col-6">
        <div class="item">
          <img src="./assets/images/client-01.png" alt="">
        </div>
      </div>
    </div>
  </div>
</section>
  </div>
</template>